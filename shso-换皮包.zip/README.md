# shso 换皮包 · 暖米白 + 香槟金

把 [yezijinn/shso](https://github.com/yezijinn/shso) 的 UI 改成参考截图那套观感：暖米白底、白卡片、香槟金主色、大圆角、几乎无阴影。
业务逻辑一行没动，只换了视觉层。

![首页](01-首页.png)

| 首页 | 文件 | 终端 | 设置 |
|---|---|---|---|
| ![](01-首页.png) | ![](02-文件.png) | ![](03-终端.png) | ![](04-设置.png) |

---

## 1. 设计令牌（全部从截图实测取色）

| 令牌 | 值 | 用途 |
|---|---|---|
| `Bg` | `#F5F4F0` | 页面底色 |
| `Surface` | `#FFFFFF` | 卡片 |
| `Gold` | `#C9A96E` | 主色 |
| `GoldHi → GoldLo` | `#D8BC85 → #BFA165` | 按钮竖向渐变 |
| `GoldText` | `#C7A871` | 强调文字、选中态 |
| `Console` | `#1C1C1E` | 终端台 |
| `Ink / Sub / Faint` | `#1C1C1E / #8E8E93 / #B0AEA8` | 三级文字 |
| `Hairline` | `#EDECE7` | 发丝分隔线 |
| 圆角 | 卡片 22dp、类型块 12dp、胶囊 50% | |
| 阴影 | 10dp 模糊、`#00000014` | 几乎看不见，只负责分层 |

字体：默认 `FontFamily.SansSerif`。想更贴原图，把 MiSans / OPPO Sans 丢进 `res/font/`，改 `ShsoTheme.kt` 里的 `ShsoFontFamily` 一行即可。

---

## 2. 文件清单

```
compose/
├── ShsoTheme.kt        # 色板 / 字阶 / 形状 / MaterialTheme 包装
├── ShsoComponents.kt   # SoftCard、GoldButton、InfoRow、ConsolePanel、
│                       # ShsoSwitch、FileTile/FileRow、LineIcon（手绘线性图标）
├── ShsoScreens.kt      # 四个页面：Home / Files / Terminal / Settings
└── ShsoApp.kt          # Scaffold + 底部导航 + 页面切换
mock/render.py          # 生成上面四张预览图的 Pillow 脚本（改色重跑即可）
```

放到：

```
app/src/main/java/com/mixradio/droid/ui/reskin/
```

包名已写成 `com.mixradio.droid.ui.reskin`，和你仓库默认包名一致；换过包名就整体替换一下。

---

## 3. 接线（3 步）

### ① 根 Composable 换成 `ShsoApp`

```kotlin
// MainActivity.kt
setContent {
    ShsoApp(
        home = {
            ShsoHomePage(
                versionName = BuildConfig.VERSION_NAME,
                running = false,                  // ← 接 RootService 的运行状态
                consoleLines = emptyList(),       // ← 接原来的输出流
                onLaunch = { /* 启动脚本 */ },
                onClearConsole = { /* 清空 */ },
                onCopyConsole = { /* 复制 */ },
                onAuthorizeDetail = { /* 跳授权详情 */ },
            )
        },
        files = { ShsoFilesPage(entries = emptyList(), onOpen = { }) },
        terminal = { ShsoTerminalPage(lines = emptyList(), onSend = { }) },
        settings = { ShsoSettingsPage() },
    )
}
```

### ② 把业务状态塞进参数

每个页面都是**无状态 + 回调**的写法，参数名一一对应原来的功能：

| 页面 | 参数 | 原来对应 |
|---|---|---|
| 首页 | `running` / `consoleLines` / `onLaunch` | `RootService` 运行状态、stdout 流、执行入口 |
| 设备信息 | `deviceName` / `kernel` / `androidVersion` / `rootInfo` | 你现在的设备信息卡 |
| 文件 | `path` / `entries` / `onOpen` | `RootFileManager` 的列表数据 |
| 终端 | `lines` / `onSend` / `onKey` | `AnsiParser` 输出、stdin |
| 设置 | 各开关 + 回调 | `AppSettings` |

### ③ 旧主题文件怎么办

- `AuroraTokens / AuroraComponents / AuroraGlass / AuroraBackground`：**可以留着不删**，只是不再被新页面引用；等你确认全站换完再删。
- `Sora` 编辑器主题 json（`assets/sora-themes/shso-dark.json`）不受影响，文本编辑器还是走 Sora 自己的配色。
- 终端 ANSI 配色想一起统一：在 `AnsiParser` 输出 → `ConsoleLine(color=...)` 的映射处，把红/黄/绿换成 `ShsoColors.TermErr / TermWarn / TermOk`，其余按 RGB 直通。

---

## 4. 怎么编译

本机**没法编译验证**（没有 JDK / Gradle，且外网被拦，拉不到依赖），所以这套代码是「源码级交付」，需要你这边出包：

**方案 A：GitHub Actions（推荐，你仓库本来就带）**
仓库自带 `.github/workflows/build-apk.yml`，支持自定义包名在线编译。把 `compose/` 四个文件 push 上去，跑一次 workflow 就能拿到 APK。

**方案 B：Android Studio**
新建分支 → 放入 `reskin/` 包 → 改 `MainActivity` → Run。

依赖不用加：这套只用 `compose-ui` / `foundation` / `material3`，图标全是 Canvas 手绘的，**不依赖 material-icons-extended**。

---

## 5. 已知差异 / 下一步

- 预览图里的**状态栏**（04:18、信号、电量）是画出来示意用的，App 内不绘制，走系统状态栏；真机上建议 `enableEdgeToEdge()` + 透明状态栏，图标用深色（浅底）。
- 首页的 `设备信息` 现在用 `Build.MODEL` / `os.version` 兜底，和原实现取的值可能不同，接回去就行。
- 文件页的底部三键（新建 / 排序 / 多选）目前是纯图标占位，替换成你原来的图标资源或 `Canvas` 线稿都可以。
- 主题色要微调（比如再暖一点 / 金再深一点）：改 `ShsoTheme.kt` 里 6 个色值，或改 `mock/render.py` 顶部的常量重跑预览图对齐。
