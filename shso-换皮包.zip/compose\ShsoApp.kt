package com.mixradio.droid.ui.reskin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * shso 新外壳：底色 + 四页 + 底部导航。
 *
 * 接线方式（三种都行）：
 *  1. 直接把 MainActivity 里的根 Composable 换成 `ShsoXinYueTheme { ShsoApp(...) }`
 *  2. 或者只替换其中的 Scaffold/bottomBar，页面各自保留自己的逻辑
 *  3. 或者只拿 ShsoTheme.kt 的色板去替换原来的 AuroraTokens
 *
 * 回调参数就是原来的业务入口，逐个接回 RootService / RootFileManager 即可。
 */
@Composable
fun ShsoApp(
    startTab: Int = 0,
    home: @Composable () -> Unit = { ShsoHomePage() },
    files: @Composable () -> Unit = { ShsoFilesPage() },
    terminal: @Composable () -> Unit = { ShsoTerminalPage() },
    settings: @Composable () -> Unit = { ShsoSettingsPage() },
) {
    var tab by rememberSaveable { mutableIntStateOf(startTab) }

    ShsoXinYueTheme {
        Scaffold(
            containerColor = ShsoColors.Bg,
            bottomBar = {
                ShsoNavBar(selected = tab, onSelect = { tab = it })
            },
        ) { inner ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(ShsoColors.Bg)
                    .padding(inner)
                    .statusBarsPadding()
            ) {
                when (tab) {
                    0 -> home()
                    1 -> files()
                    2 -> terminal()
                    else -> settings()
                }
            }
        }
    }
}

private val TabLabels = listOf("首页", "文件", "终端", "设置")

@Composable
fun ShsoNavBar(selected: Int, onSelect: (Int) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(ShsoColors.Surface)
            .navigationBarsPadding()
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(0.7.dp)
                .background(ShsoColors.Hairline)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .height(58.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TabLabels.forEachIndexed { i, label ->
                val on = i == selected
                val tint = if (on) ShsoColors.GoldText else Color(0xFFA9A69E)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .clickable { onSelect(i) },
                ) {
                    Spacer(Modifier.height(8.dp))
                    // 选中项上方那条金色短横
                    Box(
                        Modifier
                            .width(26.dp)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (on) ShsoColors.Gold else Color.Transparent)
                    )
                    Spacer(Modifier.height(7.dp))
                    LineIcon(tab = i, tint = tint)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        label,
                        color = tint,
                        fontSize = 11.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* 过渡动画（可选）：切换页面时轻微淡入                                  */
/* ------------------------------------------------------------------ */

@Composable
fun PageContainer(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopStart) { content() }
}
