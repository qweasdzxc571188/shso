package com.mixradio.droid.ui.reskin

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ------------------------------------------------------------------ */
/* 容器                                                                */
/* ------------------------------------------------------------------ */

/** 白卡片：22dp 圆角 + 几乎看不见的柔和阴影（截图里就是靠这个分层）。 */
@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    color: Color = ShsoColors.Surface,
    radius: androidx.compose.ui.unit.Dp = ShsoRadius.card,
    contentPadding: androidx.compose.foundation.layout.PaddingValues = androidx.compose.foundation.layout.PaddingValues(20.dp),
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(radius),
                clip = false,
                ambientColor = Color(0x14000000),
                spotColor = Color(0x14000000),
            )
            .clip(RoundedCornerShape(radius))
            .background(color)
            .padding(contentPadding),
        content = content,
    )
}

/** 卡片里的分组小标题（「权限」「行为」）。 */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        modifier = modifier,
        color = ShsoColors.Faint,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
    )
}

/* ------------------------------------------------------------------ */
/* 按钮                                                                */
/* ------------------------------------------------------------------ */

/** 主按钮：香槟金渐变胶囊、56dp 高、白字。 */
@Composable
fun GoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    height: androidx.compose.ui.unit.Dp = 56.dp,
) {
    val brush = if (enabled) {
        Brush.verticalGradient(listOf(ShsoColors.GoldHi, ShsoColors.GoldLo))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFDDD8CB), Color(0xFFD2CCC0)))
    }
    Box(
        modifier = modifier
            .height(height)
            .clip(RoundedCornerShape(percent = 50))
            .background(brush)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = Color(0xFFFFFDF6),
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** 次按钮 / 胶囊（「中键」「清屏」「Enter」）。 */
@Composable
fun KeyCap(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
) {
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(ShsoRadius.tile))
            .background(ShsoColors.Surface)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = if (highlight) ShsoColors.GoldText else ShsoColors.Ink,
            fontSize = 12.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/* ------------------------------------------------------------------ */
/* 信息行                                                              */
/* ------------------------------------------------------------------ */

/** 「设备名 / PLC110」这种左右对齐行，可带底部发丝线。 */
@Composable
fun InfoRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    divider: Boolean = true,
    valueColor: Color = ShsoColors.Ink,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, color = ShsoColors.Sub, fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text(
                value,
                color = valueColor,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (divider) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(0.8.dp)
                    .background(ShsoColors.Hairline)
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/* 终端台                                                              */
/* ------------------------------------------------------------------ */

data class ConsoleLine(val text: String, val color: Color = ShsoColors.TermText)

/** 深色输出台：右上角「清空 / 复制」，等宽字体逐行渲染。 */
@Composable
fun ConsolePanel(
    lines: List<ConsoleLine>,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp? = 292.dp,
    onClear: () -> Unit = {},
    onCopy: () -> Unit = {},
) {
    val sized = if (height != null) modifier.fillMaxWidth().height(height) else modifier.fillMaxSize()
    Column(
        modifier = sized
            .clip(RoundedCornerShape(ShsoRadius.panel))
            .background(ShsoColors.Console)
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            Text(
                "清空",
                color = Color(0xFFD8C39A),
                fontSize = 12.5.sp,
                modifier = Modifier.clickable(onClick = onClear),
            )
            Spacer(Modifier.width(24.dp))
            Text(
                "复制",
                color = Color(0xFFD8C39A),
                fontSize = 12.5.sp,
                modifier = Modifier.clickable(onClick = onCopy),
            )
        }
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            lines.forEach { line ->
                Text(
                    text = line.text,
                    color = line.color,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* 开关 / 行                                                           */
/* ------------------------------------------------------------------ */

@Composable
fun ShsoSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Box(
        modifier = Modifier
            .width(44.dp)
            .height(26.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(if (checked) ShsoColors.Gold else ShsoColors.TrackOff)
            .clickable { onCheckedChange(!checked) },
    ) {
        Box(
            modifier = Modifier
                .padding(3.dp)
                .size(20.dp)
                .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                .clip(RoundedCornerShape(percent = 50))
                .background(Color.White)
        )
    }
}

@Composable
fun Chevron(color: Color = ShsoColors.Faint, sizeDp: androidx.compose.ui.unit.Dp = 14.dp) {
    Canvas(Modifier.size(sizeDp)) {
        val pw = this.size.width
        val ph = this.size.height
        val p = Path().apply {
            moveTo(pw * 0.35f, ph * 0.2f)
            lineTo(pw * 0.65f, ph * 0.5f)
            lineTo(pw * 0.35f, ph * 0.8f)
        }
        drawPath(p, color, style = Stroke(width = pw * 0.13f, cap = StrokeCap.Round))
    }
}

/** 设置页的「开关行」。 */
@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    divider: Boolean = true,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = ShsoColors.Ink, fontSize = 14.5.sp)
            Spacer(Modifier.weight(1f))
            ShsoSwitch(checked, onCheckedChange)
        }
        if (divider) {
            Box(Modifier.fillMaxWidth().height(0.8.dp).background(ShsoColors.Hairline))
        }
    }
}

/** 设置页的「值 + 箭头行」。 */
@Composable
fun ValueRow(
    title: String,
    value: String,
    onClick: (() -> Unit)? = null,
    divider: Boolean = true,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = ShsoColors.Ink, fontSize = 14.5.sp)
            Spacer(Modifier.weight(1f))
            Text(value, color = ShsoColors.Sub, fontSize = 13.sp)
            if (onClick != null) {
                Spacer(Modifier.width(8.dp))
                Chevron()
            }
        }
        if (divider) {
            Box(Modifier.fillMaxWidth().height(0.8.dp).background(ShsoColors.Hairline))
        }
    }
}

/* ------------------------------------------------------------------ */
/* 文件行                                                              */
/* ------------------------------------------------------------------ */

/** 文件类型色块（截图里是浅米色圆角方块 + 金色线性图标）。 */
@Composable
fun FileTile(kind: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(RoundedCornerShape(ShsoRadius.tile))
            .background(ShsoColors.Tile),
        contentAlignment = Alignment.Center,
    ) {
        if (kind == "文件夹") {
            Canvas(Modifier.size(20.dp)) {
                val w = size.width
                val h = size.height
                drawRoundRect(
                    color = Color(0xFFE9D9B8),
                    topLeft = Offset(0f, h * 0.22f),
                    size = androidx.compose.ui.geometry.Size(w, h * 0.62f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.14f),
                )
                drawRoundRect(
                    color = Color(0xFFDCC79B),
                    topLeft = Offset(0f, h * 0.10f),
                    size = androidx.compose.ui.geometry.Size(w * 0.45f, h * 0.2f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.08f),
                )
            }
        } else {
            Text(
                text = kind,
                color = Color(0xFFB08D54),
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun FileRow(
    name: String,
    meta: String,
    kind: String,
    onClick: () -> Unit,
    divider: Boolean = true,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FileTile(kind)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    name,
                    color = ShsoColors.Ink,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(meta, color = ShsoColors.Faint, fontSize = 11.5.sp, maxLines = 1)
            }
            Chevron()
        }
        if (divider) {
            Box(Modifier.fillMaxWidth().padding(start = 50.dp).height(0.8.dp).background(ShsoColors.Hairline))
        }
    }
}

/** 底部导航用的小图标线稿（不依赖 material-icons-extended）。 */
@Composable
fun LineIcon(tab: Int, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.08f
        when (tab) {
            0 -> { // 首页
                val roof = Path().apply {
                    moveTo(w * 0.16f, h * 0.46f)
                    lineTo(w * 0.5f, h * 0.16f)
                    lineTo(w * 0.84f, h * 0.46f)
                }
                drawPath(roof, tint, style = Stroke(sw, cap = StrokeCap.Round))
                drawLine(tint, Offset(w * 0.25f, h * 0.44f), Offset(w * 0.25f, h * 0.84f), sw)
                drawLine(tint, Offset(w * 0.75f, h * 0.44f), Offset(w * 0.75f, h * 0.84f), sw)
                drawLine(tint, Offset(w * 0.25f, h * 0.84f), Offset(w * 0.75f, h * 0.84f), sw)
            }
            1 -> { // 文件
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.16f, h * 0.2f),
                    size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.62f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.1f),
                    style = Stroke(sw),
                )
                drawLine(tint, Offset(w * 0.16f, h * 0.4f), Offset(w * 0.84f, h * 0.4f), sw * 0.8f)
            }
            2 -> { // 终端
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.16f, h * 0.18f),
                    size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.66f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.14f),
                    style = Stroke(sw),
                )
                val p = Path().apply {
                    moveTo(w * 0.34f, h * 0.38f)
                    lineTo(w * 0.45f, h * 0.5f)
                    lineTo(w * 0.34f, h * 0.62f)
                }
                drawPath(p, tint, style = Stroke(sw * 0.85f, cap = StrokeCap.Round))
                drawLine(tint, Offset(w * 0.54f, h * 0.64f), Offset(w * 0.68f, h * 0.64f), sw * 0.85f)
            }
            else -> { // 设置：滑杆
                listOf(0.3f, 0.5f, 0.7f).forEachIndexed { i, y ->
                    drawLine(tint, Offset(w * 0.16f, h * y), Offset(w * 0.84f, h * y), sw * 0.85f)
                    val kx = when (i) { 0 -> 0.66f; 1 -> 0.36f; else -> 0.56f }
                    drawCircle(Color.White, radius = w * 0.075f, center = Offset(w * kx, h * y))
                    drawCircle(tint, radius = w * 0.075f, center = Offset(w * kx, h * y), style = Stroke(sw * 0.8f))
                }
            }
        }
    }
}

/** 顶部圆形头像占位（有头像图时换成 AsyncImage / painterResource 即可）。 */
@Composable
fun AvatarMark(text: String = "sh", modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(34.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(Color(0xFFE8DCC8)),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color(0xFF8A6F45), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

/** 终端字体（等宽）。 */
val ShsoMono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp)
