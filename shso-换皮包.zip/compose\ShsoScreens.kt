package com.mixradio.droid.ui.reskin

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ------------------------------------------------------------------ */
/* 顶部品牌图标                                                        */
/* ------------------------------------------------------------------ */

@Composable
fun ShsoLogo(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 34.dp) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(11.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFDCC08A), Color(0xFFBE9E60)))),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.55f)) {
            val w = this.size.width
            val h = this.size.height
            val sw = w * 0.16f
            drawLine(Color.White, Offset(w * 0.16f, h * 0.22f), Offset(w * 0.44f, h * 0.5f), sw, StrokeCap.Round)
            drawLine(Color.White, Offset(w * 0.44f, h * 0.5f), Offset(w * 0.16f, h * 0.78f), sw, StrokeCap.Round)
            drawLine(Color.White, Offset(w * 0.56f, h * 0.78f), Offset(w * 0.86f, h * 0.78f), sw, StrokeCap.Round)
        }
    }
}

/* ------------------------------------------------------------------ */
/* 首页                                                                */
/* ------------------------------------------------------------------ */

@Composable
fun ShsoHomePage(
    versionName: String = "2026.10.14",
    deviceName: String = android.os.Build.MODEL,
    kernel: String = System.getProperty("os.version") ?: "-",
    androidVersion: String = android.os.Build.VERSION.RELEASE,
    rootInfo: String = "Magisk 29.0",
    running: Boolean = false,
    consoleLines: List<ConsoleLine> = demoConsole(),
    onLaunch: () -> Unit = {},
    onClearConsole: () -> Unit = {},
    onCopyConsole: () -> Unit = {},
    onAuthorizeDetail: () -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ShsoLogo()
            Spacer(Modifier.weight(1f))
            AvatarMark()
        }
        Spacer(Modifier.height(18.dp))

        // 1. 启动卡
        SoftCard(Modifier.fillMaxWidth()) {
            GoldButton(
                text = if (running) "停止 shso" else "启动 shso",
                onClick = onLaunch,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("v$versionName", color = ShsoColors.Faint, fontSize = 12.5.sp)
                Spacer(Modifier.weight(1f))
                Text(
                    if (running) "运行中" else "未启动",
                    color = if (running) ShsoColors.GoldText else ShsoColors.Faint,
                    fontSize = 12.5.sp,
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(percent = 50))
                        .background(if (running) Color(0xFF6FCF97) else Color(0xFFD6D3CB))
                )
                Spacer(Modifier.width(8.dp))
                Text("ROOT 已授权 · $rootInfo", color = ShsoColors.Sub, fontSize = 11.5.sp)
            }
        }

        Spacer(Modifier.height(22.dp))

        // 2. 设备信息
        SoftCard(Modifier.fillMaxWidth()) {
            Text("设备信息", color = ShsoColors.Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            InfoRow("设备名", deviceName)
            InfoRow("内核版本", kernel)
            InfoRow("Android 版本", androidVersion)
            InfoRow("ROOT", rootInfo, divider = false)
        }

        Spacer(Modifier.height(22.dp))

        // 3. 输出台
        ConsolePanel(
            lines = consoleLines,
            onClear = onClearConsole,
            onCopy = onCopyConsole,
        )

        Spacer(Modifier.height(22.dp))
        Text(
            "授权详情",
            color = ShsoColors.GoldText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onAuthorizeDetail),
        )
        Spacer(Modifier.height(28.dp))
    }
}

private fun demoConsole() = listOf(
    ConsoleLine("[04:18:02] env ready", ShsoColors.TermDim),
    ConsoleLine("busybox 1.36.1  sh 7.2", ShsoColors.Gold),
    ConsoleLine("mounted  /data/adb/shso", ShsoColors.Gold),
    ConsoleLine("[ok] env unpacked  6.5 MB", ShsoColors.TermOk),
    ConsoleLine("\$ sh run.sh --check", ShsoColors.TermText),
    ConsoleLine("permission: granted", ShsoColors.TermOk),
    ConsoleLine("\$ ls -l /data/adb/shso", ShsoColors.TermText),
    ConsoleLine("-rwxr-xr-x  root  run.sh", Color(0xFF9C9C9E)),
    ConsoleLine("awaiting command...", Color(0xFF6B6B6B)),
)

/* ------------------------------------------------------------------ */
/* 文件                                                                */
/* ------------------------------------------------------------------ */

data class FsEntry(val name: String, val meta: String, val kind: String)

@Composable
fun ShsoFilesPage(
    path: String = "内部存储 / download",
    entries: List<FsEntry> = demoEntries(),
    summary: String = "共 9 项 · 已用 62% · /data/adb/shso",
    onUp: () -> Unit = {},
    onOpen: (FsEntry) -> Unit = {},
    onNew: () -> Unit = {},
    onSort: () -> Unit = {},
    onMultiSelect: () -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("文件", color = ShsoColors.Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            SearchGlyph()
        }
        Spacer(Modifier.height(16.dp))

        SoftCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(path, color = ShsoColors.Sub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Chevron()
            }
        }

        Spacer(Modifier.height(12.dp))

        SoftCard(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                entries.forEachIndexed { i, e ->
                    FileRow(
                        name = e.name,
                        meta = e.meta,
                        kind = e.kind,
                        onClick = { onOpen(e) },
                        divider = i < entries.lastIndex,
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            summary,
            color = ShsoColors.Faint,
            fontSize = 11.5.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))

        SoftCard(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                BottomAction("新建", onNew)
                BottomAction("排序", onSort)
                BottomAction("多选", onMultiSelect)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun BottomAction(label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 6.dp),
    ) {
        Box(
            Modifier
                .size(18.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFF0E7D2))
        )
        Spacer(Modifier.height(6.dp))
        Text(label, color = ShsoColors.Ink, fontSize = 11.5.sp)
    }
}

@Composable
private fun SearchGlyph() {
    Canvas(Modifier.size(22.dp)) {
        val r = size.width * 0.34f
        drawCircle(ShsoColors.Sub, radius = r, center = Offset(size.width * 0.44f, size.height * 0.44f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.075f))
        drawLine(ShsoColors.Sub, Offset(size.width * 0.68f, size.height * 0.68f), Offset(size.width * 0.9f, size.height * 0.9f), size.width * 0.075f, StrokeCap.Round)
    }
}

private fun demoEntries() = listOf(
    FsEntry("shso", "文件夹 · 12 项", "文件夹"),
    FsEntry("run.sh", "1.2 KB · 10-14 18:22", "sh"),
    FsEntry("libshso.so", "2.8 MB · 10-14 18:22", "so"),
    FsEntry("env.bin", "6.2 MB · 10-12 09:41", "bin"),
    FsEntry("backup.zip", "18.4 MB · 10-09 21:03", "zip"),
    FsEntry("notes.txt", "312 B · 10-08 12:00", "txt"),
    FsEntry("config.json", "1.8 KB · 10-08 11:52", "json"),
    FsEntry("shso.log", "84 KB · 10-07 23:10", "log"),
    FsEntry("module.prop", "196 B · 10-05 08:30", "txt"),
)

/* ------------------------------------------------------------------ */
/* 终端                                                                */
/* ------------------------------------------------------------------ */

@Composable
fun ShsoTerminalPage(
    sessionName: String = "会话 1",
    rootGranted: Boolean = true,
    lines: List<ConsoleLine> = demoTerminal(),
    onNewSession: () -> Unit = {},
    onSend: (String) -> Unit = {},
    onKey: (String) -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("终端", color = ShsoColors.Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEFEADF))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(percent = 50))
                        .background(if (rootGranted) Color(0xFF5CB87A) else Color(0xFFD6D3CB))
                )
                Spacer(Modifier.width(7.dp))
                Text("ROOT", color = Color(0xFF8A6F45), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(percent = 50))
                    .background(ShsoColors.Surface)
                    .clickable(onClick = {})
                    .padding(horizontal = 20.dp, vertical = 8.dp),
            ) {
                Text(sessionName, color = ShsoColors.Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "+",
                color = ShsoColors.Sub,
                fontSize = 17.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(percent = 50))
                    .clickable(onClick = onNewSession)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }

        Spacer(Modifier.height(14.dp))
        ConsolePanel(lines = lines, modifier = Modifier.weight(1f), height = null)

        Spacer(Modifier.height(14.dp))
        SoftCard(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("\$", color = ShsoColors.GoldText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    Text("输入命令…", color = ShsoColors.Faint, fontSize = 13.sp)
                }
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(percent = 50))
                        .background(ShsoColors.Gold)
                        .clickable { onSend("") },
                    contentAlignment = Alignment.Center,
                ) {
                    Text("↵", color = Color.White, fontSize = 15.sp)
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("中键", "清屏", "历史", "Enter").forEachIndexed { i, k ->
                KeyCap(
                    text = k,
                    onClick = { onKey(k) },
                    highlight = i == 3,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

private fun demoTerminal() = listOf(
    ConsoleLine("shso 3.8  ·  busybox 1.36.1", Color(0xFF7A7A7A)),
    ConsoleLine("", ShsoColors.TermText),
    ConsoleLine("shso@PLC110:/ \$ su", ShsoColors.TermText),
    ConsoleLine("shso@PLC110:/ # cd /data/adb/shso", ShsoColors.TermText),
    ConsoleLine("shso@PLC110:/data/adb/shso # ./run.sh", ShsoColors.TermText),
    ConsoleLine("[ok] mount -o rw,remount /system", ShsoColors.TermOk),
    ConsoleLine("[ok] chmod 755 libshso.so", ShsoColors.TermOk),
    ConsoleLine("[warn] legacy layout detected", ShsoColors.TermWarn),
    ConsoleLine("[err] open /vendor/etc: denied", ShsoColors.TermErr),
    ConsoleLine("", ShsoColors.TermText),
    ConsoleLine("shso@PLC110:/data/adb/shso # _", ShsoColors.TermText),
)

/* ------------------------------------------------------------------ */
/* 设置                                                                */
/* ------------------------------------------------------------------ */

@Composable
fun ShsoSettingsPage(
    storageGranted: Boolean = true,
    rootManager: String = "Magisk",
    installAllowed: Boolean = true,
    copyOnRun: Boolean = false,
    autoDelete: Boolean = false,
    autoRunSo: Boolean = true,
    terminalFontSp: Int = 14,
    envPackInstalled: Boolean = true,
    versionText: String = "3.8 (20261014)",
    onToggleCopy: (Boolean) -> Unit = {},
    onToggleAutoDelete: (Boolean) -> Unit = {},
    onToggleAutoRunSo: (Boolean) -> Unit = {},
    onFontSize: () -> Unit = {},
    onEnvPack: () -> Unit = {},
    onRepo: () -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Text("设置", color = ShsoColors.Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        SectionLabel("权限")
        Spacer(Modifier.height(10.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            ValueRow("存储访问", if (storageGranted) "已授权" else "未授权")
            ValueRow("ROOT 授权", rootManager)
            ValueRow("安装未知应用", if (installAllowed) "允许" else "禁止", divider = false)
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("行为")
        Spacer(Modifier.height(10.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            SwitchRow("独立存储副本", copyOnRun, onToggleCopy)
            SwitchRow("执行后自动删除", autoDelete, onToggleAutoDelete)
            SwitchRow("自动执行 .so", autoRunSo, onToggleAutoRunSo, divider = false)
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("外观")
        Spacer(Modifier.height(10.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            ValueRow("终端字号", "$terminalFontSp sp", onClick = onFontSize)
            ValueRow("扩展环境包", if (envPackInstalled) "已安装" else "未安装", onClick = onEnvPack, divider = false)
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("关于")
        Spacer(Modifier.height(10.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            ValueRow("版本", versionText, onClick = null)
            ValueRow("GitHub 仓库", "yezijinn/shso", onClick = onRepo)
            ValueRow("开源许可", "GPL-3.0", onClick = null, divider = false)
        }
        Spacer(Modifier.height(28.dp))
    }
}
