package com.mixradio.droid.ui.reskin

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * shso 视觉改造：暖米白 + 香槟金。
 *
 * 色值全部取自参考截图的实测采样（见 README），只换皮不动业务。
 * 想微调整体色温，只改 [ShsoColors] 里的 6 个主色即可。
 */
object ShsoColors {
    /** 页面底色 */
    val Bg = Color(0xFFF5F4F0)

    /** 卡片面 */
    val Surface = Color(0xFFFFFFFF)

    /** 主色（香槟金） */
    val Gold = Color(0xFFC9A96E)
    val GoldHi = Color(0xFFD8BC85)   // 按钮渐变上端
    val GoldLo = Color(0xFFBFA165)   // 按钮渐变下端
    val GoldText = Color(0xFFC7A871) // 强调文字 / 选中态
    val GoldPressed = Color(0xFFB39557)

    /** 深色终端台 */
    val Console = Color(0xFF1C1C1E)

    /** 文字 */
    val Ink = Color(0xFF1C1C1E)
    val Sub = Color(0xFF8E8E93)
    val Faint = Color(0xFFB0AEA8)

    /** 分隔线 / 索引色 */
    val Hairline = Color(0xFFEDECE7)
    val Tile = Color(0xFFF3F0E8)
    val TrackOff = Color(0xFFE4E2DB)

    /** 终端配色 */
    val TermOk = Color(0xFF6FCF97)
    val TermWarn = Color(0xFFE2C079)
    val TermErr = Color(0xFFEB7A72)
    val TermDim = Color(0xFF8E8E93)
    val TermText = Color(0xFFEDEDED)
}

object ShsoRadius {
    val card = 22.dp
    val panel = 22.dp
    val tile = 12.dp
    val pill = 999.dp
}

/** 圆润无衬线；有 MiSans / OPPO Sans 时把这里换成自定义 FontFamily 即可。 */
val ShsoFontFamily: FontFamily = FontFamily.SansSerif

val ShsoTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = ShsoFontFamily, fontWeight = FontWeight.Bold,
        fontSize = 23.sp, lineHeight = 30.sp, letterSpacing = 0.sp
    ),
    titleMedium = TextStyle(
        fontFamily = ShsoFontFamily, fontWeight = FontWeight.Bold,
        fontSize = 18.sp, lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = ShsoFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = ShsoFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 14.sp, lineHeight = 20.sp
    ),
    labelSmall = TextStyle(
        fontFamily = ShsoFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 11.5.sp, lineHeight = 16.sp
    ),
)

val ShsoShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(ShsoRadius.card),
    extraLarge = RoundedCornerShape(28.dp),
)

private val ShsoScheme = lightColorScheme(
    primary = ShsoColors.Gold,
    onPrimary = Color(0xFFFFFDF6),
    primaryContainer = Color(0xFFEFE6D2),
    onPrimaryContainer = Color(0xFF6B5327),
    secondary = ShsoColors.GoldText,
    onSecondary = Color.White,
    background = ShsoColors.Bg,
    onBackground = ShsoColors.Ink,
    surface = ShsoColors.Surface,
    onSurface = ShsoColors.Ink,
    surfaceVariant = ShsoColors.Tile,
    onSurfaceVariant = ShsoColors.Sub,
    outline = ShsoColors.Hairline,
    outlineVariant = ShsoColors.Hairline,
    error = ShsoColors.TermErr,
)

@Composable
fun ShsoXinYueTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ShsoScheme,
        typography = ShsoTypography,
        shapes = ShsoShapes,
        content = content
    )
}
