# -*- coding: utf-8 -*-
"""Render 1:1 high-fidelity mockups of the reskinned shso app (4 tabs).

Design language sampled from the user's reference screenshot:
  page #F5F4F0 / card #FFFFFF / gold #C9A96E / gold-text #C7A871
  ink #1C1C1E / sub #8E8E93 / hairline #EDECE7 / console #1C1C1E
"""
import os
import sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

SCALE = 3
W, H = 412, 916                      # dp
PX = lambda v: int(round(v * SCALE))  # dp -> px

BG      = "#F5F4F0"
CARD    = "#FFFFFF"
GOLD    = "#C9A96E"
GOLD_HI = "#D2B47F"
GOLD_LO = "#BFA165"
GOLD_TX = "#C7A871"
INK     = "#1C1C1E"
SUB     = "#8E8E93"
SUB2    = "#B0AEA8"
LINE    = "#EDECE7"
CONSOLE = "#1C1C1E"
WHITE   = "#FFFFFF"

FONT_DIR = r"C:\Windows\Fonts"


def font(name, size_dp, bold=False):
    cands = []
    if name == "mono":
        cands = ["consola.ttf", "consolab.ttf", "msyh.ttc"]
    elif bold:
        cands = ["msyhbd.ttc", "simhei.ttf"]
    else:
        cands = ["msyh.ttc", "simhei.ttf"]
    for c in cands:
        p = os.path.join(FONT_DIR, c)
        if os.path.exists(p):
            return ImageFont.truetype(p, PX(size_dp))
    return ImageFont.load_default()


def hexrgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


class Canvas:
    def __init__(self):
        self.img = Image.new("RGB", (PX(W), PX(H)), hexrgb(BG))
        self.d = ImageDraw.Draw(self.img)

    # ---- primitives -------------------------------------------------
    def shadow_card(self, box, radius, alpha=22, blur=10, dy=3, fill=CARD):
        x0, y0, x1, y1 = [PX(v) for v in box]
        r = PX(radius)
        layer = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        dl = ImageDraw.Draw(layer)
        dl.rounded_rectangle([x0, y0 + PX(dy), x1, y1 + PX(dy)], r, fill=(0, 0, 0, alpha))
        layer = layer.filter(ImageFilter.GaussianBlur(PX(blur)))
        self.img.paste(layer, (0, 0), layer)
        self.d = ImageDraw.Draw(self.img)
        self.d.rounded_rectangle([x0, y0, x1, y1], r, fill=hexrgb(fill))

    def card(self, x, y, w, h, radius=20, fill=CARD):
        self.shadow_card((x, y, x + w, y + h), radius, fill=fill)

    def rect(self, box, radius=0, fill=None, outline=None, width=1):
        b = [PX(v) for v in box]
        if radius:
            self.d.rounded_rectangle(b, PX(radius), fill=hexrgb(fill) if fill else None,
                                     outline=hexrgb(outline) if outline else None, width=PX(width))
        else:
            self.d.rectangle(b, fill=hexrgb(fill) if fill else None,
                             outline=hexrgb(outline) if outline else None, width=PX(width))

    def hline(self, x0, x1, y, color=LINE, wk=0.6):
        self.d.line([PX(x0), PX(y), PX(x1), PX(y)], fill=hexrgb(color), width=max(1, PX(wk)))

    def text(self, xy, s, size=15, color=INK, bold=False, name="ui", anchor="la"):
        f = font(name, size, bold)
        x, y = PX(xy[0]), PX(xy[1])
        amap = {"ctr": "mm", "rails": "lm", "ra": "ra", "rm": "rm", "cm": "mm", "la": "la"}
        self.d.text((x, y), s, font=f, fill=hexrgb(color), anchor=amap.get(anchor, "la"))
        return self.d.textbbox((x, y), s, font=f, anchor=amap.get(anchor, "la"))

    def tw(self, s, size=15, bold=False, name="ui"):
        f = font(name, size, bold)
        b = self.d.textbbox((0, 0), s, font=f)
        return (b[2] - b[0]) / SCALE

    def gold_button(self, x, y, w, h, label, size=17, radius=None):
        r = radius if radius is not None else h / 2
        box = (x, y, x + w, y + h)
        b = [PX(v) for v in box]
        mask = Image.new("L", self.img.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle(b, PX(r), fill=255)
        grad = Image.new("RGB", self.img.size, hexrgb(GOLD_HI))
        gd = ImageDraw.Draw(grad)
        top, bot = hexrgb(GOLD_HI), hexrgb(GOLD_LO)
        for i in range(b[1], b[3] + 1):
            t = (i - b[1]) / max(1, (b[3] - b[1]))
            gd.line([0, i, self.img.size[0], i],
                    fill=tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3)))
        self.img.paste(grad, (0, 0), mask)
        self.d = ImageDraw.Draw(self.img)
        # soft outer glow
        glow = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        ImageDraw.Draw(glow).rounded_rectangle(b, PX(r), fill=(201, 169, 110, 46))
        glow = glow.filter(ImageFilter.GaussianBlur(PX(9)))
        self.img.paste(glow, (0, -PX(2)), glow)
        self.d = ImageDraw.Draw(self.img)
        self.d.rounded_rectangle(b, PX(r), fill=None, outline=hexrgb("#B9995E"), width=1)
        cx, cy = PX(x + w / 2), PX(y + h / 2)
        self.d.text((cx, cy), label, font=font("ui", size, True), fill=hexrgb("#FFFDF6"), anchor="mm")

    def switch(self, x, y, on=True):
        w, h = 44, 26
        track = GOLD if on else "#E4E2DB"
        self.rect((x, y, x + w, y + h), radius=h / 2, fill=track)
        kx = x + w - 22 if on else x + 3
        self.d.ellipse([PX(kx), PX(y + 3), PX(kx + 20), PX(y + 23)], fill=hexrgb(WHITE))

    def chevron(self, x, y, color=SUB2, sz=5):
        self.d.line([PX(x - sz / 2), PX(y - sz), PX(x + sz / 2), PX(y),
                     PX(x - sz / 2), PX(y + sz)], fill=hexrgb(color), width=PX(1.6), joint="curve")


def status_bar(c: Canvas):
    c.text((24, 15), "04:18", 15, INK, bold=True)
    # signal bars
    bx, by = 300, 26
    for i, hh in enumerate([4, 6.5, 9, 11.5]):
        c.rect((bx + i * 6, by - hh, bx + i * 6 + 4, by), radius=1, fill=INK)
    # wifi
    cx, cy = 352, 17
    for i, rr in enumerate([11, 7.5, 4]):
        c.d.arc([PX(cx - rr), PX(cy - rr + 6), PX(cx + rr), PX(cy + rr + 6)], 200, 340,
                fill=hexrgb(INK), width=PX(1.8))
    c.d.ellipse([PX(cx - 1.4), PX(cy + 7), PX(cx + 1.4), PX(cy + 10)], fill=hexrgb(INK))
    # battery
    c.rect((372, 17, 394, 29), radius=3.5, outline=INK, width=1.2)
    c.rect((374.5, 19.5, 384, 26.5), radius=1.5, fill=INK)
    c.rect((394.6, 21, 396.4, 25), radius=1, fill=INK)


def nav_bar(c: Canvas, active=0, labels=("首页", "文件", "终端", "设置")):
    top = H - 62
    c.rect((0, top, W, H), fill=CARD)
    c.hline(0, W, top, LINE, 0.6)
    slot = W / 4
    for i, label in enumerate(labels):
        cx = slot * i + slot / 2
        on = i == active
        col = GOLD_TX if on else "#A9A69E"
        if on:
            c.rect((cx - 13, top + 10, cx + 13, top + 12.5), radius=1.4, fill=GOLD)
        ic_y = top + 26
        draw_nav_icon(c, i, cx, ic_y, col)
        c.text((cx, top + 44), label, 11, col, bold=on, anchor="ctr")
    # home indicator
    c.d.rounded_rectangle([PX(W / 2 - 60), PX(H - 6), PX(W / 2 + 60), PX(H - 2)], PX(2), fill=hexrgb("#C9C7C0"))


def draw_nav_icon(c: Canvas, idx, cx, cy, col):
    """0 home, 1 folder, 2 terminal, 3 settings."""
    colr = hexrgb(col)
    wdt = PX(1.9)
    if idx == 0:
        c.d.line([PX(cx - 8), PX(cy + 1), PX(cx), PX(cy - 7), PX(cx + 8), PX(cy + 1)], fill=colr, width=wdt, joint="curve")
        c.d.line([PX(cx - 6), PX(cy), PX(cx - 6), PX(cy + 8)], fill=colr, width=wdt)
        c.d.line([PX(cx + 6), PX(cy), PX(cx + 6), PX(cy + 8)], fill=colr, width=wdt)
        c.d.line([PX(cx - 6), PX(cy + 8), PX(cx + 6), PX(cy + 8)], fill=colr, width=wdt)
    elif idx == 1:
        c.d.rounded_rectangle([PX(cx - 8), PX(cy - 6), PX(cx + 8), PX(cy + 8)], PX(2), outline=colr, width=wdt)
        c.d.line([PX(cx - 8), PX(cy - 2), PX(cx + 8), PX(cy - 2)], fill=colr, width=PX(1.3))
    elif idx == 2:
        c.d.rounded_rectangle([PX(cx - 8), PX(cy - 7), PX(cx + 8), PX(cy + 8)], PX(2.5), outline=colr, width=wdt)
        c.d.line([PX(cx - 4), PX(cy - 3), PX(cx - 1), PX(cy), PX(cx - 4), PX(cy + 3)], fill=colr, width=PX(1.5), joint="curve")
        c.d.line([PX(cx + 0.5), PX(cy + 3.5), PX(cx + 4), PX(cy + 3.5)], fill=colr, width=PX(1.5))
    else:
        for i, yy in enumerate((-5.5, 0, 5.5)):
            c.d.line([PX(cx - 8), PX(cy + yy), PX(cx + 8), PX(cy + yy)], fill=colr, width=PX(1.6))
            kx = cx + (4 if i == 0 else (-3 if i == 1 else 2))
            c.d.ellipse([PX(kx - 2.2), PX(cy + yy - 2.2), PX(kx + 2.2), PX(cy + yy + 2.2)],
                        fill=hexrgb(CARD), outline=colr, width=PX(1.4))


def header(c: Canvas, title, right=None):
    c.text((24, 54), title, 23, INK, bold=True)


def logo(c: Canvas, x, y, s=34):
    """rounded-square gold mark with a shell prompt glyph"""
    c.rect((x, y, x + s, y + s), radius=11, fill=None)
    b = [PX(x), PX(y), PX(x + s), PX(y + s)]
    mask = Image.new("L", c.img.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle(b, PX(11), fill=255)
    grad = Image.new("RGB", c.img.size, hexrgb(GOLD_HI))
    gd = ImageDraw.Draw(grad)
    top, bot = hexrgb("#DCC08A"), hexrgb("#BE9E60")
    for i in range(b[1], b[3] + 1):
        t = (i - b[1]) / max(1, (b[3] - b[1]))
        gd.line([0, i, c.img.size[0], i], fill=tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3)))
    c.img.paste(grad, (0, 0), mask)
    c.d = ImageDraw.Draw(c.img)
    cx, cy = PX(x + s / 2), PX(y + s / 2)
    c.d.line([PX(x + 11), PX(y + 12), PX(x + 17), PX(y + 17), PX(x + 11), PX(y + 22)],
             fill=hexrgb("#FFFFFF"), width=PX(2.4), joint="curve")
    c.d.line([PX(x + 20), PX(y + 23), PX(x + 26), PX(y + 23)], fill=hexrgb("#FFFFFF"), width=PX(2.4))


# =====================================================================
# screen 1: home
# =====================================================================
def screen_home():
    c = Canvas()
    status_bar(c)

    logo(c, 24, 44, 34)
    # avatar
    ax, ay = W - 24 - 34, 44
    c.d.ellipse([PX(ax), PX(ay), PX(ax + 34), PX(ay + 34)], fill=hexrgb("#E8DCC8"))
    c.text((ax + 17, ay + 17), "sh", 12, "#8A6F45", bold=True, anchor="ctr")

    # card 1: launch
    y = 96
    c.card(24, y, W - 48, 132, 22)
    c.gold_button(44, y + 16, W - 88, 56, "启动 shso", 17)
    c.text((44, y + 88), "v2026.10.14", 12.5, SUB2)
    c.text((W - 44, y + 88), "未启动", 12.5, SUB2, anchor="ra")
    c.d.ellipse([PX(44), PX(y + 111), PX(50), PX(y + 117)], fill=hexrgb("#D6D3CB"))
    c.text((58, y + 108), "ROOT 已授权 · Magisk 29.0", 11.5, SUB)

    # card 2: device info
    y = 258
    c.card(24, y, W - 48, 214, 22)
    c.text((44, y + 20), "设备信息", 18, INK, bold=True)
    rows = [("设备名", "PLC110"), ("内核版本", "6.6.118-android15-8"), ("Android 版本", "16"), ("ROOT", "Magisk 29.0")]
    ry = y + 58
    for i, (k, v) in enumerate(rows):
        c.text((44, ry), k, 14, SUB)
        c.text((W - 44, ry), v, 14, INK, anchor="ra")
        if i < len(rows) - 1:
            c.hline(44, W - 44, ry + 27)
        ry += 39

    # card 3: console
    y = 490
    ch = 292
    c.card(24, y, W - 48, ch, 22, fill=CONSOLE)
    c.text((W - 44 - 78, y + 18), "清空", 12.5, "#D8C39A", anchor="ra")
    c.text((W - 44, y + 18), "复制", 12.5, "#D8C39A", anchor="ra")
    lines = [
        ("[04:18:02] env ready", "#8E8E93"),
        ("busybox 1.36.1  sh 7.2", "#C9A96E"),
        ("mounted  /data/adb/shso", "#C9A96E"),
        ("[ok] env unpacked  6.5 MB", "#6FCF97"),
        ("$ sh run.sh --check", "#EDEDED"),
        ("permission: granted", "#6FCF97"),
        ("$ ls -l /data/adb/shso", "#EDEDED"),
        ("-rwxr-xr-x  root  run.sh", "#9C9C9E"),
        ("awaiting command...", "#6B6B6B"),
    ]
    ly = y + 48
    for s, col in lines:
        c.text((44, ly), s, 12, col, name="mono")
        ly += 22

    c.text((W / 2, y + ch + 26), "授权详情", 14, GOLD_TX, bold=True, anchor="ctr")
    nav_bar(c, 0)
    return c.img


# =====================================================================
# screen 2: files
# =====================================================================
def screen_files():
    c = Canvas()
    status_bar(c)
    header(c, "文件")
    # search + more icons
    c.d.ellipse([PX(W - 74), PX(58), PX(W - 52), PX(80)], outline=hexrgb(SUB), width=PX(1.8))
    c.d.line([PX(W - 55), PX(77), PX(W - 48), PX(84)], fill=hexrgb(SUB), width=PX(1.8))
    for dx in (0, 6, 12):
        c.d.ellipse([PX(W - 40 + dx), PX(67), PX(W - 37 + dx), PX(70)], fill=hexrgb(SUB))

    # breadcrumb card
    y = 100
    c.card(24, y, W - 48, 52, 16)
    c.text((40, y + 16), "内部存储  /  download", 13, SUB)
    c.chevron(W - 44, y + 26, SUB2, 4)

    # list card
    y = 164
    items = [("shso", "文件夹 · 12 项", "文件夹"),
             ("run.sh", "1.2 KB · 10-14 18:22", "sh"),
             ("libshso.so", "2.8 MB · 10-14 18:22", "so"),
             ("env.bin", "6.2 MB · 10-12 09:41", "bin"),
             ("backup.zip", "18.4 MB · 10-09 21:03", "zip"),
             ("notes.txt", "312 B · 10-08 12:00", "txt"),
             ("config.json", "1.8 KB · 10-08 11:52", "json"),
             ("shso.log", "84 KB · 10-07 23:10", "log"),
             ("module.prop", "196 B · 10-05 08:30", "txt")]
    row_h = 62
    c.card(24, y, W - 48, row_h * len(items) + 12, 22)
    ry = y + 6
    for i, (name, meta, kind) in enumerate(items):
        # icon tile
        tx, ty = 40, ry + 11
        c.rect((tx, ty, tx + 38, ty + 38), radius=12, fill="#F3F0E8")
        draw_file_glyph(c, tx + 19, ty + 19, kind)
        c.text((tx + 50, ry + 13), name, 14.5, INK, bold=True)
        c.text((tx + 50, ry + 33), meta, 11.5, SUB2)
        c.chevron(W - 42, ry + 30, SUB2, 4)
        if i < len(items) - 1:
            c.hline(tx + 50, W - 44, ry + 61)
        ry += row_h

    # bottom action card
    y = H - 62 - 16 - 62
    c.card(24, y, W - 48, 62, 18)
    acts = [("新建", "plus"), ("排序", "sort"), ("多选", "check")]
    for i, (label, gly) in enumerate(acts):
        cx = 24 + (W - 48) / 3 * (i + 0.5)
        draw_action_glyph(c, cx - 9, y + 11, gly, cy=None)
        c.text((cx, y + 40), label, 11.5, INK, anchor="ctr")

    c.text((W / 2, y - 16), "共 9 项 · 已用 62% · /data/adb/shso", 11.5, SUB2, anchor="ctr")
    nav_bar(c, 1)
    return c.img


def draw_file_glyph(c: Canvas, cx, cy, kind):
    colr = hexrgb("#B08D54")
    if kind == "文件夹":
        c.d.rounded_rectangle([PX(cx - 10), PX(cy - 6), PX(cx + 10), PX(cy + 8)], PX(3), fill=hexrgb("#E9D9B8"))
        c.d.rounded_rectangle([PX(cx - 10), PX(cy - 9), PX(cx - 2), PX(cy - 4)], PX(2), fill=hexrgb("#DCC79B"))
    else:
        c.d.rounded_rectangle([PX(cx - 7), PX(cy - 9), PX(cx + 7), PX(cy + 9)], PX(2.5), outline=colr, width=PX(1.4))
        c.text((cx, cy + 1), kind, 7.5, "#B08D54", bold=True, anchor="ctr")


def draw_action_glyph(c: Canvas, x, y, kind, cy=None):
    colr = hexrgb("#B08D54")
    if kind == "plus":
        c.d.line([PX(x + 9), PX(y - 5), PX(x + 9), PX(y + 7)], fill=colr, width=PX(1.8))
        c.d.line([PX(x + 3), PX(y + 1), PX(x + 15), PX(y + 1)], fill=colr, width=PX(1.8))
    elif kind == "sort":
        for i, wdt in enumerate([14, 10, 6]):
            c.d.line([PX(x + 2), PX(y - 3 + i * 5), PX(x + 2 + wdt), PX(y - 3 + i * 5)], fill=colr, width=PX(1.8))
    else:
        c.d.line([PX(x + 2), PX(y + 1), PX(x + 7), PX(y + 6), PX(x + 16), PX(y - 6)], fill=colr, width=PX(1.9), joint="curve")


# =====================================================================
# screen 3: terminal
# =====================================================================
def screen_terminal():
    c = Canvas()
    status_bar(c)
    header(c, "终端")
    # status pill
    c.rect((W - 24 - 74, 58, W - 24, 82), radius=12, fill="#EFEADF")
    c.d.ellipse([PX(W - 24 - 64), PX(67), PX(W - 24 - 58), PX(73)], fill=hexrgb("#5CB87A"))
    c.text((W - 24 - 52, 63), "ROOT", 11.5, "#8A6F45", bold=True)

    # session tab
    y = 96
    c.rect((24, y, 24 + 96, y + 30), radius=15, fill=CARD)
    c.text((24 + 48, y + 15), "会话 1", 12, INK, bold=True, anchor="ctr")
    c.text((24 + 112, y + 15), "+", 15, SUB, anchor="ctr")

    # console
    y = 138
    ch = 500
    c.card(24, y, W - 48, ch, 22, fill=CONSOLE)
    lines = [
        ("shso 3.8  ·  busybox 1.36.1", "#7A7A7A"),
        ("", "#FFF"),
        ("shso@PLC110:/ $ su", "#EDEDED"),
        ("shso@PLC110:/ # cd /data/adb/shso", "#EDEDED"),
        ("shso@PLC110:/data/adb/shso # ./run.sh", "#EDEDED"),
        ("[ok] mount -o rw,remount /system", "#6FCF97"),
        ("[ok] chmod 755 libshso.so", "#6FCF97"),
        ("[warn] legacy layout detected", "#E2C079"),
        ("[err] open /vendor/etc: denied", "#EB7A72"),
        ("", "#FFF"),
        ("shso@PLC110:/data/adb/shso # _", "#EDEDED"),
    ]
    ly = y + 22
    for s, col in lines:
        c.text((40, ly), s, 11.5, col, name="mono")
        ly += 25
    # scroll indicator
    c.d.rounded_rectangle([PX(W - 34), PX(y + 60), PX(W - 31), PX(y + 200)], PX(1.5), fill=hexrgb("#3A3A3C"))

    # input row
    y2 = y + ch + 14
    c.card(24, y2, W - 48, 54, 18)
    c.text((40, y2 + 18), "$", 14, GOLD_TX, bold=True, name="mono")
    c.text((66, y2 + 17), "输入命令…", 13, "#A9A69E")
    c.d.rectangle([PX(60), PX(y2 + 17), PX(61.4), PX(y2 + 33)], fill=hexrgb(GOLD_TX))
    # send button
    c.d.ellipse([PX(W - 44 - 34), PX(y2 + 10), PX(W - 44 + 0), PX(y2 + 44)], fill=hexrgb(GOLD))
    c.d.line([PX(W - 44 - 19), PX(y2 + 19), PX(W - 44 - 19), PX(y2 + 34)], fill=hexrgb(WHITE), width=PX(1.9))
    c.d.line([PX(W - 44 - 25), PX(y2 + 27), PX(W - 44 - 13), PX(y2 + 27)], fill=hexrgb(WHITE), width=PX(1.9))

    # quick keys
    y3 = y2 + 66
    keys = ["中键", "清屏", "历史", "Enter"]
    kw = (W - 48 - 3 * 8) / 4
    for i, k in enumerate(keys):
        x = 24 + i * (kw + 8)
        c.rect((x, y3, x + kw, y3 + 34), radius=12, fill=CARD)
        c.text((x + kw / 2, y3 + 17), k, 12, INK if k != "Enter" else GOLD_TX, bold=k == "Enter", anchor="ctr")

    nav_bar(c, 2)
    return c.img


# =====================================================================
# screen 4: settings
# =====================================================================
def screen_settings():
    c = Canvas()
    status_bar(c)
    header(c, "设置")

    def group(y, title, rows):
        c.text((40, y), title, 12, SUB2, bold=True)
        gy = y + 20
        h = 12 + 46 * len(rows)
        c.card(24, gy, W - 48, h, 22)
        ry = gy + 6
        for i, row in enumerate(rows):
            kind = row[0]
            label = row[1]
            c.text((42, ry + 13), label, 14.5, INK)
            if kind == "switch":
                c.switch(W - 44 - 44, ry + 10, row[2])
            elif kind == "value":
                c.text((W - 44, ry + 13), row[2], 13, SUB, anchor="ra")
                c.chevron(W - 30, ry + 20, SUB2, 3.5)
            elif kind == "plain":
                c.text((W - 44, ry + 13), row[2], 13, SUB2, anchor="ra")
            if i < len(rows) - 1:
                c.hline(42, W - 44, ry + 45)
            ry += 46
        return gy + h

    y = 96
    y = group(y, "权限", [("value", "存储访问", "已授权"),
                          ("value", "ROOT 授权", "Magisk"),
                          ("value", "安装未知应用", "允许")]) + 18
    y = group(y, "行为", [("switch", "独立存储副本", False, True),
                          ("switch", "执行后自动删除", False, False),
                          ("switch", "自动执行 .so", True, False)]) + 18
    y = group(y, "外观", [("value", "终端字号", "14 sp"),
                          ("value", "扩展环境包", "已安装")]) + 18
    y = group(y, "关于", [("plain", "版本", "3.8 (20261014)"),
                          ("value", "GitHub 仓库", "yezijinn/shso"),
                          ("plain", "开源许可", "GPL-3.0")])

    nav_bar(c, 3)
    return c.img


def main():
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    out = os.path.abspath(out)
    os.makedirs(out, exist_ok=True)
    for name, fn in [("01-首页.png", screen_home), ("02-文件.png", screen_files),
                     ("03-终端.png", screen_terminal), ("04-设置.png", screen_settings)]:
        img = fn()
        p = os.path.join(out, name)
        img.save(p, "PNG")
        print("wrote", p, img.size)


if __name__ == "__main__":
    main()
